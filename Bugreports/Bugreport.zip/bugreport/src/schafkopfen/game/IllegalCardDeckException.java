package schafkopfen.game;

public class IllegalCardDeckException extends Exception {
    public IllegalCardDeckException(String message) {
        super(message);
    }
}
